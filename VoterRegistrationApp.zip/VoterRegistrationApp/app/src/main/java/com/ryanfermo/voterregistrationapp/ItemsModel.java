package com.ryanfermo.voterregistrationapp;

public class ItemsModel {
    private String president1;
    private String president2;
    private String vice1;
    private String vice2;
    private String secretary1;
    private String secretary2;
    private String treasurer1;
    private String treasurer2;
    private String auditor1;
    private String auditor2;
    private String pro1;
    private String pro2;
    private String rep1;
    private String rep2;
    private String president11;
    private String president21;
    private String vice11;
    private String vice21;
    private String secretary11;
    private String secretary21;
    private String treasurer11;
    private String treasurer21;
    private String auditor11;
    private String auditor21;
    private String pro11;
    private String pro21;
    private String rep11;
    private String rep21;
    private String id;
    private String ardate;
    public ItemsModel(){

    }

    public ItemsModel(String president1, String president2, String vice1, String vice2, String secretary1, String secretary2, String treasurer1, String treasurer2,
                      String auditor1, String auditor2, String pro1, String pro2, String rep1, String rep2, String president11, String president21, String vice11, String vice21, String secretary11, String secretary21, String treasurer11, String treasurer21,
                      String auditor11, String auditor21, String pro11, String pro21, String rep11, String rep21, String ardate, String id) {
        this.president1 = president1;
        this.president2 = president2;
        this.vice1 = vice1;
        this.vice2 = vice2;
        this.secretary1 = secretary1;
        this.secretary2 = secretary2;
        this.treasurer1 = treasurer1;
        this.treasurer2 = treasurer2;
        this.auditor1 = auditor1;
        this.auditor2 = auditor2;
        this.pro1 = pro1;
        this.pro2 = pro2;
        this.rep1 = rep1;
        this.rep2 = rep2;
        this.president11 = president11;
        this.president21 = president21;
        this.vice11 = vice11;
        this.vice21 = vice21;
        this.secretary11 = secretary11;
        this.secretary21 = secretary21;
        this.treasurer11 = treasurer11;
        this.treasurer21 = treasurer21;
        this.auditor11 = auditor11;
        this.auditor21 = auditor21;
        this.pro11 = pro11;
        this.pro21 = pro21;
        this.rep11 = rep11;
        this.rep21 = rep21;
        this.ardate=ardate;
        this.id=id;
    }
    public String getPresident1() {
        return president1;
    }

    public String getPresident2() {
        return president2;
    }

    public String getVice1() {
        return vice1;
    }

    public String getVice2() {
        return vice2;
    }

    public String getSecretary1() {
        return secretary1;
    }

    public String getSecretary2() {
        return secretary2;
    }

    public String getTreasurer1() {
        return treasurer1;
    }

    public String getTreasurer2() {
        return treasurer2;
    }

    public String getAuditor1() {
        return auditor1;
    }

    public String getAuditor2() {
        return auditor2;
    }

    public String getPro1() {
        return pro1;
    }

    public String getPro2() {
        return pro2;
    }

    public String getRep1() {
        return rep1;
    }

    public String getRep2() {
        return rep2;
    }
    public String getPresident11() {
        return president11;
    }

    public String getPresident21() {
        return president21;
    }

    public String getVice11() {
        return vice11;
    }

    public String getVice21() {
        return vice21;
    }

    public String getSecretary11() {
        return secretary11;
    }

    public String getSecretary21() {
        return secretary21;
    }

    public String getTreasurer11() {
        return treasurer11;
    }

    public String getTreasurer21() {
        return treasurer21;
    }

    public String getAuditor11() {
        return auditor11;
    }

    public String getAuditor21() {
        return auditor21;
    }

    public String getPro11() {
        return pro11;
    }

    public String getPro21() {
        return pro21;
    }

    public String getRep11() {
        return rep11;
    }

    public String getRep21() {
        return rep21;
    }
    public String getArdate() {
        return ardate;
    }
    public String getId() {
        return id;
    }
}
